#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define largura 12
#define altura 12

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	srand(time(NULL));
	int p_x = 2;
	int p_y = 1;
	int g_x = largura -3;
	int g_y = altura -2;
	int c_x = largura -6;
	int c_y = altura -2;
	int por_x = largura -7;
	int por_y = altura -12;
	int chave_p = 0;
	int p;
	int x;
	int i;
	int j;
	int move;
	int move_g;
	char mapa[largura][altura];
	
	system("cls");
	while(x != 3){
	printf("*********ENTER THE DUNGEON*********");
	printf("\n*   1)START                       *");
	printf("\n*   2)TUTORIAL                    *");
	printf("\n*   3)SAIR                        *\n");
	
	scanf("%d", &x);
		if(x==1){
			
		//limpar tabuleiro	
		for(i = 0; i < largura; i++) {
       		 for(j = 0; j < altura; j++) {
            // Verifica se est� na borda
            if(i == 0 || i == largura - 1 || j == 0 || j == altura - 1) {
                mapa[i][j] = '*'; // Se estiver na borda, coloca *
            } else {
                mapa[i][j] = ' '; // Caso contr�rio, deixa vazio
            }
        }
    }
    
		//posi��o inicial//
			mapa[p_y][p_x] = '&'; // jogador
			mapa[g_y][g_x] = 'X'; // Ini
			mapa[c_y][c_x] = 'C'; // Chave
			mapa[por_y][por_x] = 'D'; // Porta
			
		//desenho	
		for(i = 0; i < largura; i++) {
        	for(j = 0; j < altura; j++) {
         	   printf("%c", mapa[i][j]);
        	}
        printf("\n");
		} 
			
			//logica
			//MOVIMENTO PLAYER//
		while(1){
			move = getch();
			mapa[p_y][p_x] = ' ';
			switch(move){
				case 'a':{
					if (p_x > 1)
					p_x--;
				}break;
				case 'd':{
					if (p_x < largura - 2)
					p_x++;
				}break;
				case 'w':{
					if (p_y > 1)
					p_y--;
				}break;
				case 's':{
					if (p_y < altura - 2)
					p_y++;
				}break;
			}
			// Atualiza a posi��o do JOGADOR no mapa
			mapa[p_y][p_x] = '&';
			
		//MOVIMENTO INIMIGO // DESATIVAR 
		mapa[g_y][g_x] = ' ';
		move_g = rand()%4;
		switch(move_g) {
            case 0:
                if (g_x > 1)
                    g_x--;
                break;
            case 1:
                if (g_x < largura - 2)
                    g_x++;
                break;
            case 2:
                if (g_y > 1)
                    g_y--;
                break;
            case 3:
                if (g_y < altura - 2)
                    g_y++;
                break;
        }
		// Atualiza a posi��o do INIMIGO no mapa
		mapa[g_y][g_x] = 'X';// DESATINVAR */
		
		 // Desenhar mapa
    	system("cls");
        for(i = 0; i < largura; i++) {
            for(j = 0; j < altura; j++) {
                printf("%c", mapa[i][j]);
            }
            printf("\n");
        } 
		
	if (p_x==g_x && p_y==g_y){
		printf("Um inimigo surgiu das sombras e te matou...");
	break;
	}
	
	if (p_x==c_x && p_y == c_y){
		chave_p = 1;
		mapa[c_y][c_x] = ' ';
		por_y = altura -11;
		mapa[por_y][por_x] = '=';
		printf("Chave encontrada");
	}
    
        // Verifica se o jogador alcan�ou o objetivo
        if (p_x == por_x && p_y == por_y) {
        	system("cls");
            printf("Parab�ns, voc� alcan�ou o objetivo!\n");
            if (!chave_p) {
                printf("Voc� abriu a porta e passou para a pr�xima fase!\n");
            }
            break;
        }
    }
    
}

	/*	
	if(x==2){
		system("cls");
		printf(" W: O jogador movimenta uma unidade para cima\n A: O jogador movimenta uma unidade para esquerda;\n S: O jogador movimenta uma unidade para baixo;\n D: O jogador movimenta uma unidade para direita;\n I: O jogador interage com o objeto que est� em cima. \n");
		printf(" &: Simbolo que representa o jogador.");
		printf(" *: Simbolo que representa uma parede, o jogador ao se movimentar n�o pode passar pela parede.\n ");	
		printf(" @: Simbolo que representa a chave para abrir a porta para finalizar a fase, a porta abre no momento que o jogador interage com a chave.\n");	
		printf(" D: Simbolo que representa a porta fechada.\n");	
		printf(" =: Simbolo que representa a porta aberta quando o jogador interage com a chave.\n");	
		printf(" O: Simbolo que representa um bot�o que o usu�rio pode interagir, o bot�o fica no ch�o e o jogador deve ficar em cima dele para poder interagir.\n");	
		printf(" #: Simbolo que representa um espinho. A fase � reiniciada quando o jogador toca no espinho, caso a fase seja reiniciada tr�s vezes, o jogo volta para o menu principal.\n");	
		printf(" >::Simbolo que representa um teletransporte. O teletransporte sempre deve vir em pares, quando o jogador toca em um ele � transportado para o outro e vice-versa.\n");	
		printf(" X: Simbolo que representa o monstro n�vel 1. Esse monstro tem um movimento aleat�rio para cima, para esquerda, para baixo e para direita. Caso o monstro toque no jogador, a fase � reiniciada.\n");	
		printf(" V: S�mbolo que representa o monstro n�vel 2. Esse monstro tem uma intelig�ncia para seguir o jogador (h� v�rias maneiras de implementar isso). Caso o monstro toque no jogador, a fase � reiniciada. \n");	
		printf(" \n5)<--BACK \n");	
		scanf("%d", &x);
		system("cls");
	}	
	if(x==3){
		exit;
		system("cls");
	}*/
}


	return 0;
}
