#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define largura 10
#define altura 10

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	srand(time(NULL));
	int p_x = 0;
	int p_y = 0;
	int g_x = largura -1;
	int g_y = altura -1;
	int t_x = largura -2;
	int t_y = altura -2;
	int j;
	int i;
	char tab[largura][altura];
	char move;
	int move_g;
	
	while(1){
		// Tabuleiro VAZIO
		for(i=0;i<largura;i++){
			for(j=0;j<altura;j++){
				tab[i][j] = ' ';
			}
		
	}	 
	//POSI��O INICIAL
		tab[p_y][p_x] = '@';
		tab[g_y][g_x] = 'G';
		tab[t_y][t_x] = 'T';
	
	// Tabuleiro DESENHADO
		for(i=0;i<largura;i++){
			for(j=0;j<altura;j++){
				printf("[%c]", tab[i][j]);
			}
			printf("\n");
		} 
		
		
		//MOVIMENTO PLAYER//
		move = getch();
		switch(move){
			case 'a':{
					p_x--;
			}break;
			case 'd':{
					p_x++;
			}break;
			case 'w':{
					p_y--;
			}break;
			case 's':{
					p_y++;
			}break;
		}
		//MOVIMENTO FIROTTO
		move_g = rand()%2;
		if (move_g==0){
			if(p_x>g_x){
				g_x++;
			}else{
				g_x--;
			}
		}if(p_y<g_y){
				g_y--;
			}else{
				g_y++;
			}
		
		
		if(p_x==t_x && p_y==t_y){
			system("cls");
			printf("Vc perdeu tempo pra isso?");
			break;
		}
		if(p_x==g_x && p_y==g_y){
			system("cls");
			printf("GIROTTO LHE GIROTTOU");
			break;
		}
		
		
		
		system("cls");
	}
	
	
	return 0;
}
